const express = require('express');
const dbConnect = require('./config/dbConnect');
const router = require('./routes/users');
const path = require('path')
const app = express();
const cors = require('cors');

app.use(cors());

app.use(express.json());

// connect to db
dbConnect();
// Middlewares
app.use(express.json({ extended: false }));
app.use(express.static(path.join(__dirname, "/public")));

// Routes
app.use('/users', router);

if (process.env.NODE_ENV === 'production') {
  app.use(express.static('client/build'))

  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'client', 'build', 'index.html')) // relative path
  })
}

const PORT =   4000 || process.env.PORT;
  
app.listen(4000, (err) =>
  err ? console.error(err) : console.log(`connection on port ${PORT}`)
);